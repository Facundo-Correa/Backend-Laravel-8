Exportando registros desde: catalogo_can
